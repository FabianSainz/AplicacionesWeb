<?php
$horaNormal = $_REQUEST['horaNormal'];
$horaExtra = $_REQUEST['horaExtra'];

$pagoFinal = ($horaNormal * 120.0) + ($horaExtra * 200.0);

echo"SUELDO <br> Tu Sueldo final es de: " . $pagoFinal . "<br>";
?>