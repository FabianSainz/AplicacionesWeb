<?php
   $nombre = $_POST['nombre'];
   $apellido = $_POST['apellido'];
   $dia = $_POST['dia'];
   $mes = $_POST['mes'];
   $anio = $_POST['anio'];
   $genero = $_POST['genero'];

   $dia_actual = date('d');
   $mes_actual = date('m');
   $anio_actual = date('Y');

   $edad = $anio_actual - $anio;

   if($mes_actual < $mes){
       $edad--;
   }
   elseif($mes_actual == $mes){
       if($dia_actual < $dia){
           $edad--;
       }
   }
   if($edad >= 18){
       if($genero == "masculino"){
           echo "Hola señor " .$nombre." ".$apellido.". Usted tiene ".$edad . " años.";
       }
       else{
           echo "Hola señora " .$nombre." ".$apellido.". Usted tiene ".$edad . " años.";
       }
   }
   else{
       if($genero == "masculino"){
           echo "Hola " .$nombre." ".$apellido.". Tienes ".$edad . " años.";
       }
       else{
           echo "Hola " .$nombre." ".$apellido.". Tienes ".$edad . " años.";
       }
   }
?>