<!DOCTYPE html>
<html lang="es-ES">
 
<head>
	<meta charset="utf-8">
	<title>Conversor de Semanas a dias</title>
	<meta name="description" content="Conversor de distancias">
</head>
 
<body>
	<section align="center">
 
		<h4 style="text-align:center;">Unidades</h4>
		<p align="center">
			
			1 Semana = 7 dias<br>
		</p>
		<form method="POST" action="#">
			<div align="center">
				<input type="text" name="valor" value="<?php if(!empty($_POST['valor'])){ echo $_POST['valor'];} ?>" />
				<select name="tipo">
					<option value="<?php if(!empty($_POST['tipo'])){ echo $_POST['tipo'];} ?>">

						<?php
						 if(!empty($_POST['tipo'])){ 

							 echo $_POST['tipo'];} 

						 else{

					      echo 'Seleccione';} 

						 ?>

					</option>
					
					<option value="Semanas">Semanas</option>
					
				</select>
				<input type="submit" name="calculo" value="Convertir">
			</div>
		</form>
		<h4 align="center">Cálculo en PHP</h4>
		<p align="center">
 
			<?php
 
if (isset($_POST['calculo'])) {
	$valor = $_POST['valor'];
	$tipo = $_POST['tipo'];
 
	switch ($tipo) {
 
		case 'Semanas':
 
			echo '
			Dias: '.$valor * (7) .'<br>';
			break;
 
	default:
 
		echo 'No hay unidades a convertir';
 
		break;
	}
 
}
?>
		</p>
	</section>
</body>
 
</html>