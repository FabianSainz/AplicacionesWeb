<!DOCTYPE html>
<html lang="es-ES">
 
<head>
	<meta charset="utf-8">
	<title>Conversor de distancias</title>
	<meta name="description" content="Conversor de distancias">
</head>
 
<body>
	<section align="center">
 
		<h4 style="text-align:center;">Unidades</h4>
		<p align="center">
			
			1 Milla = 1.60934 Kilometros<br>
			1 Kilometro = 0.621371 Millas<br>
		</p>
		<form method="POST" action="#">
			<div align="center">
				<input type="text" name="valor" value="<?php if(!empty($_POST['valor'])){ echo $_POST['valor'];} ?>" />
				<select name="tipo">
					<option value="<?php if(!empty($_POST['tipo'])){ echo $_POST['tipo'];} ?>">

						<?php
						 if(!empty($_POST['tipo'])){ 

							 echo $_POST['tipo'];} 

						 else{

					      echo 'Seleccione';} 

						 ?>

					</option>
					
					<option value="Kilometro">Kilometros</option>
					<option value="Milla">Millas</option>
					
				</select>
				<input type="submit" name="calculo" value="Convertir">
			</div>
		</form>
		<h4 align="center">Cálculo en PHP</h4>
		<p align="center">
 
			<?php
 
if (isset($_POST['calculo'])) {
	$valor = $_POST['valor'];
	$tipo = $_POST['tipo'];
 
	switch ($tipo) {
 
		case 'Milla':
 
			echo '

			Millas: '.$valor.'<br>
			Kilometros: '.$valor * (1.609) .'<br>
			';
			break;
 
		case 'Kilometro':
 
			echo '

			Millas: '.$valor * (0.6214) .'<br>
			Kilometros: '.$valor.'<br>
			';
			break;
 
	default:
 
		echo 'No hay unidades a convertir';
 
		break;
	}
 
} else {
	echo 'No hay valores a convertir';
}
?>
		</p>
	</section>
</body>
 
</html>