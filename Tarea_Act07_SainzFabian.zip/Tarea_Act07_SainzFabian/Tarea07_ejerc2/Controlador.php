<?php

if ($_SERVER['REQUEST_METHOD']=='POST')
{
    $capital_inicial = floatval ($_POST['capital_inicial']);
    $capital_final=$capital_inicial*.02;
    echo 'Valor de capital que ha obtenido es de: ' . $capital_final . "<br/>\n";
}
 require_once "Vista.html";
?>